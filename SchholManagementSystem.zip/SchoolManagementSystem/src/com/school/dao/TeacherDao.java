package com.school.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;






import com.school.utils.DbConnector;
import com.school.model.Teacher;

public class TeacherDao {

	public void registerTeacher(Teacher teacher) {

		Connection conn=null;
		PreparedStatement ps = null;
		//boolean flag=false;
		
		try
		{
			conn=DbConnector.getConnection();
			
			ps=conn.prepareStatement("insert into teacher(firstname,lastname,age,address,email,phonenumber,experience) values(?,?,?,?,?,?,?)");
			 ps.setString(1,teacher.getFname());
             ps.setString(2,teacher.getLname());
             ps.setInt(3,teacher.getAge());
             ps.setString(4,teacher.getAddress());
             ps.setString(5,teacher.getEmail());
             ps.setString(6,teacher.getContact_number());
             ps.setInt(7,teacher.getExp());
             
             int rowInserted = ps.executeUpdate();
 			 System.out.println(rowInserted);
		}
		
		catch (Exception e)
		{
			e.printStackTrace();	
	    }
		
		finally
        {
              try
              {
                    conn.close();
              }
              catch(SQLException e)
              {
                    System.out.println(e.getMessage());
              }
        }   

	}

	public List<Teacher> listTeacher() throws SQLException {
		
		ResultSet rs = null;
		Connection conn=null;
		List<Teacher> teacherlist = new ArrayList<>();

		
		try {
			conn=DbConnector.getConnection();
			PreparedStatement st = conn.prepareStatement("select * from teacher");
			rs = st.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String fname = rs.getString("firstname");
				String lname = rs.getString("lastname");
				int age=rs.getInt("age");
				String address=rs.getString("address");
				String email=rs.getString("email");
				String phn=rs.getString("phonenumber");
				int exp=rs.getInt("experience");

				Teacher teacher = new Teacher();
				teacher.setId(id);
				teacher.setFname(fname);
				teacher.setLname(lname);
				teacher.setAge(age);
				teacher.setAddress(address);
				teacher.setEmail(email);
				teacher.setContact_number(phn);
				teacher.setExp(exp);
				
				teacherlist.add(teacher);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally
        {
            try
            {
                  conn.close();
            }
            catch(SQLException e)
            {
                  System.out.println(e.getMessage());
            }
      }   
		return teacherlist;
	}

	public Teacher getTeacher(int id) {
		
		Teacher teacher=null;
		Connection conn=null;
		ResultSet rs = null;

		try {
			conn=DbConnector.getConnection();
			
			PreparedStatement st = conn.prepareStatement("SELECT * FROM teacher WHERE id = ?");
			st.setInt(1,id);

			rs = st.executeQuery();

			if (rs.next()) {
				int Id = rs.getInt("id");
				String fname = rs.getString("firstname");
				String lname = rs.getString("lastname");
				int age = rs.getInt("age");
				String address=rs.getString("address");
				String email=rs.getString("email");
				String phn=rs.getString("phonenumber");
				int exp=rs.getInt("experience");
				teacher = new Teacher(Id, fname, lname, age, address, email, phn, exp);		
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally
        {
            try
            {
                  conn.close();
            }
            catch(SQLException e)
            {
                  System.out.println(e.getMessage());
            }
      }   
		return teacher;
	}

	public void updateTeacher(Teacher teacher) {
		
		Connection conn=null;

		try {
			
			conn=DbConnector.getConnection();
			

			PreparedStatement ps = conn.prepareStatement("UPDATE teacher SET firstname = ?, lastname = ?, age = ?, address=?, email=?, phonenumber=?, experience=? WHERE id = ?");
			
			
			 ps.setString(1,teacher.getFname());
             ps.setString(2,teacher.getLname());
             ps.setInt(3,teacher.getAge());
             ps.setString(4,teacher.getAddress());
             ps.setString(5,teacher.getEmail());
             ps.setString(6,teacher.getContact_number());
             ps.setInt(7,teacher.getExp());
             ps.setInt(8,teacher.getId());


			int rowUpdateStatus = ps.executeUpdate();

			System.out.println("No of rows updated...." + rowUpdateStatus);

		} catch (Exception e)
		{
			e.printStackTrace();	
	    }
		
		finally
        {
              try
              {
                    conn.close();
              }
              catch(SQLException e)
              {
                    System.out.println(e.getMessage());
              }
        }  
	}
	
	public void deleteCustomer(int Id)  {
		
		Connection conn=null;
		
		try {
			
			conn=DbConnector.getConnection(); 
			
			PreparedStatement ps = conn.prepareStatement("DELETE FROM teacher where id = ?");
			ps.setInt(1,Id);
			int count = ps.executeUpdate();
			System.out.println("No of rows deleted...." + count);
		} catch (Exception e)
		{
			e.printStackTrace();	
	    }
		
		finally
        {
              try
              {
                    conn.close();
              }
              catch(SQLException e)
              {
                    System.out.println(e.getMessage());
              }
        }  
	}
}
