package com.school.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.school.model.Teacher;
import com.school.service.TeacherBO;

import org.apache.log4j.Logger;


@WebServlet(description = "Functionalities for personnel management", urlPatterns = { "/TeacherController" })
public class TeacherController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static Logger log=Logger.getLogger(TeacherController.class);
  
    public TeacherController()
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String ac = request.getParameter("act");
		
		if (ac != null) {
			if (ac.equals("displayRegistrationForm")) {
				displayRegistrationForm(request, response);
			} 
			else if (ac.equals("listTeacher")) {
				listTeacher(request, response);
		}
			 else if (ac.equals("deleteTeacher")) {
					deleteTeacher(request, response);
				}
			else if (ac.equals("EditDetails")) {
				editDetails(request, response);
			} else
			{
				listTeacher(request, response);
			}
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("act");
		
		if (action!= null) {
			if (action.equals("registerTeacher"))
			{
				registerTeacher(request, response);
			} 
			else if (action.equals("updateTeacher"))
			{
				updateTeacher(request, response);
			}
			else
			{
			}
		}
		else
		{
			System.out.println("no action specified...");
		}
	}
	
	private void registerTeacher(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			int age = Integer.parseInt(request.getParameter("age"));
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String number= request.getParameter("phn");
			int exp= Integer.parseInt(request.getParameter("exp"));

			Teacher teacher = new Teacher();
			teacher.setFname(fname);
			teacher.setLname(lname);
			teacher.setAge(age);
			teacher.setAddress(address);
			teacher.setEmail(email);
			teacher.setContact_number(number);
			teacher.setExp(exp);
			
			log.debug("message");
			
			TeacherBO.registerTeacher(teacher);
			
			response.sendRedirect("" + getServletContext().getContextPath() + "/TeacherController?act=listTeacher");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void displayRegistrationForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/TeacherRegistration.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void listTeacher(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Teacher> teacherList = TeacherBO.listTeacher();
			request.setAttribute("teacherList", teacherList);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/ListTeachers.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void editDetails(HttpServletRequest request, HttpServletResponse response) {
		try {
			String Id = request.getParameter("id");
			Teacher teacher = TeacherBO.getTeacher(Integer.parseInt(Id));
			request.setAttribute("teacher", teacher);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/EditDetails.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void updateTeacher(HttpServletRequest request, HttpServletResponse response) {
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			int age = Integer.parseInt(request.getParameter("age"));
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String number= request.getParameter("phn");
			int exp= Integer.parseInt(request.getParameter("exp"));

			Teacher teacher = new Teacher();
			teacher.setId(id);
			teacher.setFname(fname);
			teacher.setLname(lname);
			teacher.setAge(age);
			teacher.setAddress(address);
			teacher.setEmail(email);
			teacher.setContact_number(number);
			teacher.setExp(exp);
			
			TeacherBO.updateTeacher(teacher);
			
			response.sendRedirect("" + getServletContext().getContextPath() + "/TeacherController?act=listTeacher");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void deleteTeacher(HttpServletRequest request, HttpServletResponse response) {
		try {
			String Id = request.getParameter("id");
			TeacherBO.deleteTeacher(Integer.parseInt(Id));
			
			response.sendRedirect("" + getServletContext().getContextPath() + "/TeacherController?act=listTeacher");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}


