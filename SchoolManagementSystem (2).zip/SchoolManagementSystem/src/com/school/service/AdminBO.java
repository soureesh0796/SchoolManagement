package com.school.service;

import com.school.dao.AdminDao;
import com.school.model.Admin;

public class AdminBO {

	public static boolean validateAdmin(Admin admin) {
		
		AdminDao admindao=new AdminDao();
		boolean result=admindao.validateAdmin(admin);
		return result;
	}

}
