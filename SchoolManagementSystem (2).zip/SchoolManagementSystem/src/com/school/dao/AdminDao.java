package com.school.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import com.school.model.Admin;
import com.school.utils.DbConnector;

public class AdminDao {

	public boolean validateAdmin(Admin admin) {
		
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		boolean bn=false;
		
		try
		{
			conn=DbConnector.getConnection();
			ps=conn.prepareStatement("select * from admin where username=? and password=?");
			
			ps.setString(1,admin.getUsername());
			ps.setString(2,admin.getPassword());
			rs=ps.executeQuery();
			
			if(rs.next())
			{
				bn=true;
			}
			else
			{
				bn=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		return bn;
	}

}
