package com.school.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import com.school.model.Teacher;

public class TeacherDao extends SchoolBaseDao{
	
	public void registerTeacher(Teacher teacher)
	{
		try
		{
			
			em=getEntityManager();
			em.getTransaction().begin();
			em.persist(teacher);
			em.getTransaction().commit();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}
	}
	
	public List<Teacher> listTeacher()
	{
		List<Teacher> listTeacher=new ArrayList<>();
		try
		{
			em=getEntityManager();
			em.getTransaction().begin();
			
			Query query=em.createQuery("from Teacher");
			listTeacher=(List<Teacher>)query.getResultList();
			
			em.getTransaction().commit();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}
		
		return listTeacher;
	}
	
	
	public Teacher getTeacher(int id)
	{
		try
		{
			em=getEntityManager();
			em.getTransaction().begin();
			
			teacher=em.find(Teacher.class,id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}
		
		return teacher;
	}
	
	public void updateTeacher(Teacher teacher)
	{
		Teacher t=null;
		try
		{
			em=getEntityManager();
			em.getTransaction().begin();
			
			t=em.find(Teacher.class,teacher.getId());
			
			t.setId(teacher.getId());
			t.setFname(teacher.getFname());
			t.setLname(teacher.getLname());
			t.setAge(teacher.getAge());
			t.setAddress(teacher.getAddress());
			t.setEmail(teacher.getEmail());
			t.setContact_number(teacher.getContact_number());
			t.setExp(teacher.getExp());
			
			em.getTransaction().commit();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			closeEntityManager();
		}
	}


	public void deleteTeacher(int id) {
		
		try
		{
			//teacher.setId(id);
			em=getEntityManager();
			em.getTransaction().begin();
			teacher=em.find(Teacher.class,id);
			em.remove(teacher);
			
			em.getTransaction().commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}
		
	}
	
}
