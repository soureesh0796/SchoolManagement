package com.school.dao;

import java.util.ArrayList;
import java.util.List;

import com.school.model.Subject;
import com.school.model.Teacher;

public class SubjectDao extends SchoolBaseDao{

	public void addSubject(Subject subject) {
		
		try
		{
			Teacher teacher=new Teacher();
			em=getEntityManager();
			em.getTransaction().begin();
			em.persist(subject);
			em.getTransaction().commit();
			
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}	
	}

	public List<Subject> getList(int t_id) {
		
		List<Subject> list=new ArrayList<>();
		try
		{em=getEntityManager();
		em.getTransaction().begin();
		Teacher t = em.find(Teacher.class, t_id);
		em.getTransaction().commit();
		
		list=t.getSubjectList();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			closeEntityManager();
		}	
		return list;
		
	}

}
