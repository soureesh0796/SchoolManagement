package com.school.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.school.model.Subject;
import com.school.model.Teacher;
import com.school.service.SubjectBO;

@WebServlet("/SubjectController")
public class SubjectController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public SubjectController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String ac=request.getParameter("act");
		
		if(ac!=null)
		{
			if(ac.equals("displaySubjectForm"))
				displaySubjectForm(request,response);	
			else if (ac.equals("showSubjectPage"))
				showSubjectPage(request, response);
			else if (ac.equals("listSubject"))
				listSubject(request, response);
		}	
		else
		{
		}
	}

	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("act");
		
		if (action!= null) {
			if (action.equals("addSubject"))
			{
				addSubject(request, response);
			} 
			
		}
			else
			{
				System.out.println("no action specified...");
			}
	}
	
	private void showSubjectPage(HttpServletRequest request, HttpServletResponse response) {
		
		try
		{
			int teacherID=Integer.parseInt(request.getParameter("id"));
			System.out.println(teacherID);
			request.setAttribute("teacherID", teacherID);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/Subject.jsp");
			rd.forward(request, response);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displaySubjectForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			System.out.println("Inside Subject Controller");
			request.setAttribute("id", request.getAttribute("id"));
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/AddSubject.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
private void addSubject(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			String sname = request.getParameter("sname");
			String scat = request.getParameter("scat");
			System.out.println(request.getParameter("id"));
			int t_id=Integer.parseInt(request.getParameter("id").trim());
			System.out.println(t_id);

			Subject subject=new Subject();
			Teacher teacher= new Teacher();
			teacher.setId(t_id);
			subject.setName(sname);
			subject.setCategory(scat);
			subject.setTeacher(teacher);
			
			SubjectBO.addSubject(subject);
				
			response.sendRedirect("" + getServletContext().getContextPath() + "/TeacherController?act=listTeacher");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

private void listSubject(HttpServletRequest request, HttpServletResponse response) {
	
	try{
		
		System.out.println("Inside Controller List Teachers");
		
		int t_id=Integer.parseInt(request.getParameter("id"));
		System.out.println(t_id);
		
		List<Subject> subjectList=SubjectBO.getlist(t_id); 
		
		int size=subjectList.size();
		
		System.out.println(size);
		
		for(Subject s:subjectList)
		{
			System.out.println(s.getName());
		}
		
		request.setAttribute("subjectList", subjectList);
		request.setAttribute("size", size);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/ListSubjects.jsp");
		rd.forward(request, response);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}

}
