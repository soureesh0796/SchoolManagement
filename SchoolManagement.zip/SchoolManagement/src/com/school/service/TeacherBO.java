package com.school.service;

import java.util.List;
import com.school.dao.TeacherDao;
import com.school.model.Teacher;

public class TeacherBO {

	public static void registerTeacher(Teacher teacher) {
		
		TeacherDao teacherdao=new TeacherDao();
		teacherdao.registerTeacher(teacher);
	}

	public static List<Teacher> listTeacher() {
		List<Teacher> teacherList=null;
		try {
			TeacherDao teacherdao=new TeacherDao();
		    teacherList = teacherdao.listTeacher();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return teacherList;
	}

	public static Teacher getTeacher(int Id) {
		TeacherDao teacherdao = new TeacherDao();
		return teacherdao.getTeacher(Id);
	}

	public static void updateTeacher(Teacher teacher) {
		TeacherDao teacherdao = new TeacherDao();
		teacherdao.updateTeacher(teacher);
	}

	public static void deleteTeacher(int Id) {
		TeacherDao teacherdao = new TeacherDao();
		teacherdao.deleteTeacher(Id);
	}
	

}
