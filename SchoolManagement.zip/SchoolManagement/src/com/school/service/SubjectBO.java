package com.school.service;

import java.util.List;

import com.school.dao.SubjectDao;
import com.school.model.Subject;

public class SubjectBO {

	public static void addSubject(Subject subject) {
		
		SubjectDao subjectdao=new SubjectDao();
		subjectdao.addSubject(subject);
		
	}

	public static List<Subject> getlist(int t_id) {
		
		SubjectDao subjectdao=new SubjectDao();
		List<Subject> slist=subjectdao.getList(t_id);
		return slist;
	}

}
